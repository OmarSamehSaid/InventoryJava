
package registeration;

 import javax.swing.*;
 import java.awt.*;
public class Project {

    
    public static void main(String[] args) {
    Login l =new Login();
    }
    }
    

